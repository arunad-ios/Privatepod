# InventorySwiftCocoapods

[![CI Status](https://img.shields.io/travis/ct-vikram/InventorySwiftCocoapods.svg?style=flat)](https://travis-ci.org/ct-vikram/InventorySwiftCocoapods)
[![Version](https://img.shields.io/cocoapods/v/InventorySwiftCocoapods.svg?style=flat)](https://cocoapods.org/pods/InventorySwiftCocoapods)
[![License](https://img.shields.io/cocoapods/l/InventorySwiftCocoapods.svg?style=flat)](https://cocoapods.org/pods/InventorySwiftCocoapods)
[![Platform](https://img.shields.io/cocoapods/p/InventorySwiftCocoapods.svg?style=flat)](https://cocoapods.org/pods/InventorySwiftCocoapods)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

InventorySwiftCocoapods is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'InventorySwiftCocoapods'
```

## Author

ct-vikram, vikramarkareddy@cartrade.com

## License

InventorySwiftCocoapods is available under the MIT license. See the LICENSE file for more info.
