//
//  MyPrivatePod.h
//  MyPrivatePod
//
//  Created by Chandini on 26/03/25.
//

#import <Foundation/Foundation.h>

//! Project version number for MyPrivatePod.
FOUNDATION_EXPORT double MyPrivatePodVersionNumber;

//! Project version string for MyPrivatePod.
FOUNDATION_EXPORT const unsigned char MyPrivatePodVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MyPrivatePod/PublicHeader.h>


